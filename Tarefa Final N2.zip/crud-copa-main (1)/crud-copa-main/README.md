# Exemplo_CRUD_Mongo
Exemplo paras Aulas
## Após fazer o download execute "npm install" para baixar as bibliotecas.
Caso queira começar do zero execute: "npm i dotenv ejs mongodb mongoose express multer express-session", pode ser uma biblioteca por vez.

Boa parte dessas bibliotecas serão para manipular arquivo.
